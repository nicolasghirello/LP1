#include "aluno.h"
int Aluno::Aluno(){

}
/*Aluno(std::string _matricula, std::string _nome){

}*/
std::string Aluno::getNome(){
	return nome;
}